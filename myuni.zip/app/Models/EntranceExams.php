<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class EntranceExams extends Model
{
    use HasFactory;

    // protected $dateFormat = 'd-m-Y';
    
    protected $fillable =['admission_year' ,'name','description','code','courses','exam_date','reg_start_date','reg_last_date','fee','result_date'];

    protected $casts = [
        'courses'=>'json',
    ];
}
