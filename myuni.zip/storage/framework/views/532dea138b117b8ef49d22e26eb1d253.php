

<?php $__env->startSection('content'); ?>
<div class="container-fluid py-5">
    <div class="container py-5">
        <div class="row mx-0 justify-content-center">
            <div class="col-lg-8">
                <div class="section-title text-center position-relative mb-5">
                    <h6 class="d-inline-block position-relative text-secondary text-uppercase pb-2">Courses</h6>
                    <h1 class="display-4">Checkout Our Courses</h1>
                </div>
            </div>
        </div>
        <div class="row">
            <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-lg-4 col-md-6 pb-4">
                     <a class="courses-list-item position-relative d-block overflow-hidden mb-2" href="<?php echo e(route('show.courseDetail',$course->id)); ?>">
                        <img class="img-fluid" src="<?php echo e(asset('img/img/courses-1.jpg')); ?>" alt="">
                        <div class="courses-text">
                        <h4 class="text-center text-white px-3"><?php echo e($course->name); ?></h4>
                            <div class="border-top w-100 mt-3">
                                <div class="d-flex justify-content-between p-4">
                                <span class="text-white"><i class="fa fa-user mr-2"></i><?php echo e($course->stream->name); ?></span>
                                <span class="text-white"><i class="fa fa-star mr-2"></i><?php echo e($course->category->name); ?></span>
                                </div>
                            </div>
                        </div>
                    </a>
                </div>        
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
               
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\myuni-2\myuni\resources\views/pages/course/courseList.blade.php ENDPATH**/ ?>