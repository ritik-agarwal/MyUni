<select class="form-control<?php echo e($errors->has($attribute) ? ' is-invalid' : ''); ?>" 
    name="<?php echo e($attribute); ?>" id="input-<?php echo e($id); ?>" <?php echo e(($required) ? 'required' : ''); ?>

    <?php echo e(($multiselect) ? 'multiple' : ''); ?>>
    <?php echo e($slot); ?>

</select><?php /**PATH C:\xampp\htdocs\myuni-2\myuni\resources\views/components/common/select.blade.php ENDPATH**/ ?>