<div class="form-group">
    <div class="form-check">
        <input class="form-check-input" type="checkbox" value="" id="flexCheckChecked" required>
        <label class="form-check-label" for="flexCheckChecked">
            I agree to <a href="#">terms and conditions</a>
        </label>
    </div>
</div>